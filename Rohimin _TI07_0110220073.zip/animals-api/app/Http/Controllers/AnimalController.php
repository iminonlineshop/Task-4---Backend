<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnimalController extends Controller
{
   public $animals = [
		[
			"name" => "Kucing",
		],
		[
			"name" => "Ayam",
		],
		[
			"name" => "Ikan"
		]
	];
   
   public function index() {
      echo "Menampilkan data animals";
      echo "<br>";
      foreach ($this->animals as  $animal) {
         echo "Nama hewan : $animal[name] ";
         echo "<br>";
     }
   }

   public function store(Request $request) {
      echo "Menambahkan hewan baru <br>";
      array_push($this->animals, $request);
		$this->index(); 
   }

   public function update(Request $request, $id) {
		echo 'Mengupdate data hewan id '.$this->animals[$id]['name'].' to '.$request->name.'<br>';
		$this->animals[$id] = $request;
		$this->index();
   }

   function destroy($id) {
    echo "Menghapus data hewan dari id  $id <br>"; 
		array_splice($this->animals, $id, 1);
		$this->index();  
   }
}

